import requests
from bs4 import BeautifulSoup
import datetime
import csv
import os
import lxml
import re
import time
import pandas
hh = []
for j in range(2011,2020):
    yy = str(j)
    for i in range(1,12+1):
        if j == 2019 and i==12:
            break
        else:
            mm = str(i).zfill(2)
            r = requests.get(url="http://www.tianqihoubao.com/lishi/beijing/month/"+yy+mm+".html")
            soup = BeautifulSoup(r.text,'lxml')
            tds = soup.find_all("tr")
            for i in tds:
                hh.append(i.get_text().replace("\r\n", "").replace("\n\n", "").replace("\n", "").replace(" ", ""))
data = pandas.DataFrame({'a':hh})
data.to_csv("hekou.csv",index=False,sep=',',encoding="gb2312")